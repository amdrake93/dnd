package Dice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class DieCommandProcessor {
	private static final List<String> AVAILABLE_COMMANDS = Arrays.asList("roll",
			"crit");
	private static final String CRIT_COMMAND = "crit";
	private static final String BIG_UNDERLINE = "----------";

	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		while (true) {
			try {
				String input = sc.nextLine();
				String[] inputSplitOnSpaces = input.split(" ");

				if (inputSplitOnSpaces.length < 2) {
					System.out.println("No input found\n");
					continue;
				}

				String command = inputSplitOnSpaces[0];
				if (!AVAILABLE_COMMANDS.contains(command)) {
					System.out.println("Invalid command found, please use one of the following:\n");
					for (String currCommand : AVAILABLE_COMMANDS) {
						System.out.println(currCommand + "\n");
					}
				}

				String dieInput = inputSplitOnSpaces[1];
				List<String> additions = new ArrayList<>(Arrays.asList(dieInput.split("\\+")));
				List<String> purgedAdditions = new ArrayList<>();
				List<String> subtractions = findSubtractionsFromAdditionSplit(additions, purgedAdditions);

				boolean crit = CRIT_COMMAND.equals(command);
				StringBuilder addSb = new StringBuilder("Additions: ");
				Long additionResult = handleDieRolls(purgedAdditions, crit, addSb);
				StringBuilder subSb = new StringBuilder("Subtractions: ");
				Long subtractionResult = handleDieRolls(subtractions, crit, subSb);
				System.out.println(addSb.toString());
				System.out.println(BIG_UNDERLINE);
				System.out.println(subSb.toString());
				System.out.println(BIG_UNDERLINE);
				System.out.println("Result: " + (additionResult - subtractionResult));
			} catch (Throwable e) {
				System.out.println("error");
			}
		}
	}

	private static Long handleDieRolls(List<String> dice, boolean crit, StringBuilder sb) {
		Long result = 0l;
		for (String dieString : dice) {
			if (dieString.isEmpty()) {
				continue;
			}
			if (dieString.indexOf("d") == (dieString.length() - 1)) {
				System.out.println("Missing a die type\n");
				continue;
			}
			String[] diceParts = dieString.split("d");
			if (diceParts.length == 1) {
				int modifier = Integer.valueOf(diceParts[0]);
				sb.append(modifier + " ");
				result += modifier;
				continue;
			}
			Integer amount = diceParts[0].isEmpty() ? 1 : Integer.valueOf(diceParts[0]);
			Integer value = Integer.valueOf(diceParts[1]);
			Die die = new Die(amount, value);
			int dieResult = die.rollDie(crit);
			sb.append(dieResult + " ");
			result += dieResult;
		}
		return result;
	}

	private static List<String> findSubtractionsFromAdditionSplit(List<String> additions, List<String> purgedAdditions) {
		List<String> subtractions = new ArrayList<>();
		for (String addition : additions) {
			String[] possibleSubtractions = addition.split("\\-");
			if (possibleSubtractions.length > 1) {
				purgedAdditions.add(possibleSubtractions[0]);
				for (int i = 1; i < possibleSubtractions.length; i++) {
					subtractions.add(possibleSubtractions[i]);
				}
			} else {
				purgedAdditions.add(possibleSubtractions[0]);
			}
		}
		return subtractions;
	}
}
