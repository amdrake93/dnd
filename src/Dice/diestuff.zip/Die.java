package Dice;

import java.util.Random;

public class Die {
	public int amount;
	public int value;

	public Die(int amount, int value) {
		this.amount = amount;
		this.value = value;
	}

	public int rollDie(boolean crit) {
		int result = 0;
		int amountOfDie = crit ? this.amount * 2 : this.amount;
		if (this.value == 1) {
			return amountOfDie;
		}
		for (int i = 0; i < amountOfDie; i++) {
			Random rng = new Random();
			int rollResult = rng.nextInt(this.value) + 1;
			result += rollResult;
		}
		return result;
	}
}
